path(a,L).
path(L,M).
mother(N,O).
grandfather(Whoall,WhoaLL).
;