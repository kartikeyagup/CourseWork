path(L,M).
;