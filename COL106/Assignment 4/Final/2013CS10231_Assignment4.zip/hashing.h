#ifndef HASHING_H
#define HASHING_H

#include <string>
#include <iostream>

using namespace std;

int getCharValue(string,int);
long getHashKey(string,long);

#endif