#ifndef WORDDECOMPRESS_H
#define WORDDECOMPRESS_H

#include <vector>
#include "HashTable.h"

string* initialize(int);
string Decompress(vector<int>,int);

#endif
