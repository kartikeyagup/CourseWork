// YOU DO NOT NEED TO MODIFY THIS INSTRUCTOR-PROVIDED FILE.
// Your code should work properly with an unmodified version of this file.

#ifndef MISC_H
#define MISC_H

#include <cstdio>
#include <string>
#include <stdlib.h>

using namespace std;

void printAndExit(string message);

#endif
